/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   heap_queue.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ahbarbou <ahbarbou@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/08 12:15:10 by ahbarbou          #+#    #+#             */
/*   Updated: 2026/09/13 21:52:09 by ahbarbou         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "codex.h"


int     compare_requests(t_request a, t_request b, int scheduler)
{
    // fifo
    if (scheduler == 0)
    {
        if (a.arrival_order != b.arrival_order)
            return (a.arrival_order < b.arrival_order);
        return (a.coder_id < b.coder_id);
    }
    // edf
    if (a.deadline != b.deadline)
        return (a.deadline < b.deadline);
    if (a.arrival_order != b.arrival_order)
        return (a.arrival_order < b.arrival_order);
    return (a.coder_id < b.coder_id);
}

void    heap_swap(t_request *a, t_request *b)
{
    t_request   tmp;


    tmp = *a;
    *a = *b;
    *b = tmp;
}

void     heap_init(t_heap *heap, int capacity)
{
    heap->capacity = capacity;
    heap->size = 0;
    heap->requests = malloc(sizeof(t_request) * capacity);
    if (!heap->requests)
        return ;
}

void    heap_push(t_heap *heap, t_request req, int scheduler)
{
    int     i;
    int     parent;


    if (heap->size > heap->capacity)
        return ;
    i = heap->size++;
    heap->requests[i] = req;

    while (i > 0)
    {
        parent = (i - 1) / 2;
        if (compare_requests(heap->requests[i], heap->requests[parent], scheduler))
        {
            heap_swap(&heap->requests[i], &heap->requests[parent]);
            i = parent;
        }
        else
            break;
    }
}

t_request	heap_pop(t_heap *heap, int scheduler)
{
	t_request	min_req;
	int			i;
	int			left;
	int			right;
	int			smallest;


	min_req = heap->requests[0];
	heap->requests[0] = heap->requests[--heap->size];
	i = 0;

	while (1)
	{
		left = 2 * i + 1;
		right = 2 * i + 2;
		smallest = i;
		if (left < heap->size && compare_requests(heap->requests[left], heap->requests[smallest], scheduler))
			smallest = left;
		if (right < heap->size && compare_requests(heap->requests[right], heap->requests[smallest], scheduler))
			smallest = right;
		if (smallest != i)
		{
			heap_swap(&heap->requests[i], &heap->requests[smallest]);
			i = smallest;
		}
		else
			break ;
	}
	return (min_req);
}

t_request *pick_next(t_dongle *d)
{
    if (d->queue.size == 0)
        return (NULL);
    return (&d->queue.requests[0]);
}

// int main()
// {
//     t_heap  queue;
//     t_request req_1;
//     t_request req_2;
//     t_request req_3;
//     int i = 0;

//     heap_init(&queue, 2);
//     queue.size = 0;
//     queue.capacity = 2;

//     req_1.coder_id = 0;
//     req_1.arrival_order = 111;
//     req_1.deadline = 111;

//     req_2.coder_id = 1;
//     req_2.arrival_order = 222;
//     req_2.deadline = 222;

//     req_3.coder_id = 2;
//     req_3.arrival_order = 333;
//     req_3.deadline = 333;

//     heap_push(&queue, req_1, 0);
//     heap_push(&queue, req_2, 0);

//     while (i < queue.capacity)
//     {
//         printf(
//             "%d) id: %d, order: %ld, deadline: %ld\n",
//             i,
//             queue.requests[i].coder_id,
//             queue.requests[i].arrival_order,
//             queue.requests[i].deadline
//         );
//         i++;
//     }
//     heap_pop(&queue, 0);
//     heap_push(&queue, req_3, 0);
   
//     i = 0;
//     printf("second capacity %d\n", queue.capacity);
//     while (i < queue.capacity)
//     {
//         printf(
//             "%d) id: %d, order: %ld, deadline: %ld\n",
//             i,
//             queue.requests[i].coder_id,
//             queue.requests[i].arrival_order,
//             queue.requests[i].deadline
//         );
//         i++;
//     }
//     heap_pop(&queue, 0);
//     heap_pop(&queue, 0);
//     printf("therd capacity: %d", queue.size);
// }
